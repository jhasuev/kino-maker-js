export const locale = {
}
