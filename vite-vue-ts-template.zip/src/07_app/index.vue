<script setup lang="ts">
import { RouterView } from '@/05_pages'
</script>

<template>
  <RouterView />
</template>
