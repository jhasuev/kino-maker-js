import { storeApp } from './app'

export { storeApp }
