import { app } from './07_app'

app.mount('#app')
