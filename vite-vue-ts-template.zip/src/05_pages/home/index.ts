import Home from './ui.vue'
export default Home
