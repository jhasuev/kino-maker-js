<script setup lang="ts">
defineOptions({ name: 'home' })
</script>

<template>
  <div>
    home
  </div>
</template>
