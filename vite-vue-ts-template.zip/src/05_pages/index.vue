<script setup lang="ts">
defineOptions({ name: 'Pages' })
</script>

<template>
  <div>
    <RouterView />
  </div>
</template>
