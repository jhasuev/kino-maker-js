import ErrorPage404 from './ui.vue'
export default ErrorPage404
