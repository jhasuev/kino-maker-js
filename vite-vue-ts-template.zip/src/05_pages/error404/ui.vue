<script setup lang="ts">
defineOptions({ name: 'error404' })
</script>

<template>
  <div>
    404
  </div>
</template>
